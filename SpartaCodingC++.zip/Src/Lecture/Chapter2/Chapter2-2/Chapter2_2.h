﻿#pragma once

int Chapter2_2HWMain();

template <typename T>
T add(const T& left, const T& right)
{
	return left + right;
}