﻿#pragma once

int Chapter1_1HWMain();

int RepeatPrintStars();